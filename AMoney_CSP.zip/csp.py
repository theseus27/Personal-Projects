#
# csp.py
# Written by Austen Money, 3/30/22
#

import time

# class represents one square of the sudoku puzzle
class Blank():
    def __init__(self, row, column, value):
        self.domain = []
        self.value = value
        self.rowNeighbors = []
        self.columnNeighbors = []
        self.gridNeighbors = []
        self.row = row
        self.column = column

    def __eq__(self, other):
        return type(self) == type(other)
        return self.domain == other.domain
        return self.value == other.value
        return self.rowNeighbors == other.rowNeighbors
        return self.columnNeighbors == other.columnNeighbors
        return self.gridNeighbors == other.gridNeighbors
        return self.row == other.row
        return self.column == other.column

# prints the formatted puzzle
def printPuzzle(puzzle):

    print("+" + "---+"*9)
    for i, row in enumerate(puzzle):
        print(("|" + " {}   {}   {} |"*3).format(*[x.value if x.value != 0 else " " for x in row]))
        if i % 3 == 2:
            print("+" + "---+"*9)

        else:
            print("|" + "     "*7 + "|")

# assign a domain to each variable object in puzzle by checking the values of
# every set of neighbors
def assignDomain(puzzle):

    for a in range(0, len(puzzle)):
        for b in range(0, len(puzzle[a])):
            # whenever we encounter one of these in a neighbor, we will eliminate it
            puzzle[a][b].domain = [1, 2, 3, 4, 5, 6, 7, 8, 9]
            if puzzle[a][b].value != 0:
                puzzle[a][b].domain = [] # pre-assigned variables have no domain
            else:
                for i in range(0, len(puzzle[a][b].rowNeighbors)):
                    if puzzle[a][b].rowNeighbors[i].value in puzzle[a][b].domain:
                        puzzle[a][b].domain.remove(puzzle[a][b].rowNeighbors[i].value)

                for i in range(0, len(puzzle[a][b].columnNeighbors)):
                    if puzzle[a][b].columnNeighbors[i].value in puzzle[a][b].domain:
                        puzzle[a][b].domain.remove(puzzle[a][b].columnNeighbors[i].value)

                for i in range(0, len(puzzle[a][b].gridNeighbors)):
                    if puzzle[a][b].gridNeighbors[i].value in puzzle[a][b].domain:
                        puzzle[a][b].domain.remove(puzzle[a][b].gridNeighbors[i].value)

    return puzzle

# assign row, column, and grid neighbors to each variable object in puzzle
def assignNeighbors(puzzle):

    for a in range(0, len(puzzle)):
        for b in range(0, len(puzzle[a])):
            # assign row and column neighbors (only free blanks) to puzzle[a][b]
            for i in range(0, len(puzzle)):
                puzzle[a][b].columnNeighbors.append(puzzle[a][i])
                puzzle[a][b].rowNeighbors.append(puzzle[i][b])

            # assign grid neighbors to puzzle[a][b]
            if a < 3:
                if b < 3:
                    for i in range(0, 3):
                        for p in range(0, 3):
                            puzzle[a][b].gridNeighbors.append(puzzle[i][p])

                elif b < 6:
                    for i in range(0, 3):
                        for p in range(3, 6):
                            puzzle[a][b].gridNeighbors.append(puzzle[i][p])

                elif b < 9:
                    for i in range(0, 3):
                        for p in range(6, 9):
                            puzzle[a][b].gridNeighbors.append(puzzle[i][p])

            elif a < 6:
                if b < 3:
                    for i in range(3, 6):
                        for p in range(0, 3):
                            puzzle[a][b].gridNeighbors.append(puzzle[i][p])

                elif b < 6:
                    for i in range(3, 6):
                        for p in range(3, 6):
                            puzzle[a][b].gridNeighbors.append(puzzle[i][p])

                elif b < 9:
                    for i in range(3, 6):
                        for p in range(6, 9):
                            puzzle[a][b].gridNeighbors.append(puzzle[i][p])

            elif a < 9:
                if b < 3:
                    for i in range(6, 9):
                        for p in range(0, 3):
                            puzzle[a][b].gridNeighbors.append(puzzle[i][p])

                elif b < 6:
                    for i in range(6, 9):
                        for p in range(3, 6):
                            puzzle[a][b].gridNeighbors.append(puzzle[i][p])

                elif b < 9:
                    for i in range(6, 9):
                        for p in range(6, 9):
                            puzzle[a][b].gridNeighbors.append(puzzle[i][p])

    return puzzle

# returns true if every variable in the puzzle has been assigned a value
def isComplete(puzzle):

    for i in range(0, len(puzzle)):
        for p in range(0, len(puzzle[i])):
            if puzzle[i][p].value == 0:
                return False

    return True

# returns false if n is already assigned to one of curr's neighbors or if
# assigning n to curr will deplete the domains of any neighbors
def isConsistent(curr, n):

    values = [n] # will be used to ensure there are no duplictate values
    for i in range(0, len(curr.rowNeighbors)):
        # check for duplicate values
        if (curr.rowNeighbors[i].value != 0) and (curr.rowNeighbors[i].value in values):
            return False
        # check if assigning n would deplete a neighboring domain
        if (len(curr.rowNeighbors[i].domain) == 1) and (n in curr.rowNeighbors[i].domain) and (curr.rowNeighbors[i] != curr):
            return False
        values.append(curr.rowNeighbors[i].value)

    values = [n]
    for i in range(0, len(curr.columnNeighbors)):
        # check for duplicate values
        if (curr.columnNeighbors[i].value != 0) and (curr.columnNeighbors[i].value in values):
            return False
        # check if assigning n would deplete a neighboring domain
        if (len(curr.columnNeighbors[i].domain) == 1) and (n in curr.columnNeighbors[i].domain) and (curr.columnNeighbors[i] != curr):
            return False
        values.append(curr.columnNeighbors[i].value)

    values = [n]
    for i in range(0, len(curr.gridNeighbors)):
        # check for duplicate values
        if (curr.gridNeighbors[i].value != 0) and (curr.gridNeighbors[i].value in values):
            return False
        # check if assigning n would deplete a neighboring domain
        if (len(curr.gridNeighbors[i].domain) == 1) and (n in curr.gridNeighbors[i].domain) and (curr.gridNeighbors[i] != curr):
            return False
        values.append(curr.gridNeighbors[i].value)

    return True

# sets a given variable's value to n, and removes n from neighboring domains
def assignValue(curr, n):

    curr.value = n
    for i in range(0, len(curr.rowNeighbors)):
        if n in curr.rowNeighbors[i].domain:
            curr.rowNeighbors[i].domain.remove(n)

    for i in range(0, len(curr.columnNeighbors)):
        if n in curr.columnNeighbors[i].domain:
            curr.columnNeighbors[i].domain.remove(n)

    for i in range(0, len(curr.gridNeighbors)):
        if n in curr.gridNeighbors[i].domain:
            curr.gridNeighbors[i].domain.remove(n)

    return curr

# backtracking function that recurses through available values to assign a
# value to each variable of the puzzle
def backtrack(puzzle, blanks, steps):

    if isComplete(puzzle):
        return puzzle

# move to first variable with a non-empty domain
    curr = blanks[0]
    p = 0
    for i in range(0, len(blanks)):
        if len(blanks[i].domain) > 0:
            curr = blanks[i]
            break

# find variable in blanks list with smallest (non-empty) domain and set it to curr
    for i in range(0, len(blanks)):
        if (len(blanks[i].domain) < len(curr.domain)) and (len(blanks[i].domain) > 0):
            curr = blanks[i]
            p = i

# try assigning each value in curr's domain, backtracking whenever the domain of
# a neighboring variable is emptied
    for i in range(0, len(curr.domain)):
        if isConsistent(curr, curr.domain[i]):
            blanks.pop(p)
            curr = assignValue(curr, curr.domain[i])
            if steps: # print each assignment if requested
                printPuzzle(puzzle)
            result = backtrack(puzzle, blanks, steps)

            if result != False:
                return result

    return False # means we have explored every legal combination of value assignments

# CSP function that transforms integer sudoku array into Blank object array
# and calls backtracking function to solve the puzzle.
def CSP(puzzle, steps):

# create a new version of the puzzle 9x9 array made up of Blank objects instead
# of integers, so that the domains of each object and its neighbors can be
# checked later on
    valPuzzle = []
    for i in range(0, len(puzzle)):
        newRow = []
        for p in range(0, len(puzzle[i])):
            newBlank = Blank(i, p, puzzle[i][p])
            newRow.append(newBlank)
        valPuzzle.append(newRow)

# assign row, column, and grid neighbors to each Blank object, then assign a domain
# based on those neighbors' values
    valPuzzle = assignNeighbors(valPuzzle)
    valPuzzle = assignDomain(valPuzzle)

    print("Initial puzzle:")
    printPuzzle(valPuzzle) # prints blank spaces for every object assigned 0

    blanks = [] # will hold the Blank objects yet to be assigned a value

# fill the blanks list with variables that need values
    for i in range(0, len(valPuzzle)):
        for p in range(0, len(valPuzzle[i])):
            if valPuzzle[i][p].value == 0:
                blanks.append(valPuzzle[i][p])

# call recursive backtracking function
    newPuzzle = backtrack(valPuzzle, blanks, steps)

    if newPuzzle == False:
        print("No solution found.")
        return False

    print("Finished puzzle:")
    printPuzzle(newPuzzle)

# main function that calls CSP function
def main():
    puzzle = [[6, 0, 8, 7, 0, 2, 1, 0, 0],
             [4, 0, 0, 0, 1, 0, 0, 0, 2],
             [0, 2, 5, 4, 0, 0, 0, 0, 0],
             [7, 0, 1, 0, 8, 0, 4, 0, 5],
             [0, 8, 0, 0, 0, 0, 0, 7, 0],
             [5, 0, 9, 0, 6, 0, 3, 0, 1],
             [0, 0, 0, 0, 0, 6, 7, 5, 0],
             [2, 0, 0, 0, 9, 0, 0, 0, 8],
             [0, 0, 6, 8, 0, 5, 2, 0, 3]]

    start = time.time() # keep track of how long the operation takes

    CSP(puzzle, False) # call CSP algorithm without steps shown

    end = time.time()
    print("Time to complete:", end-start, "seconds")

    ans = input("Would you like to see a step-by-step solution? (y/n) ")

    if ans == "y":
        start = time.time() # keep track of how long the operation takes

        CSP(puzzle, True) # call CSP algorithm with each step shown

        end = time.time()
        print("Time to complete:", end-start, "seconds")
        return 0
    else:
        return 0

if __name__ == '__main__':
    main()
